﻿namespace mini_RSA {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.tbP = new MetroFramework.Controls.MetroTextBox();
            this.tbQ = new MetroFramework.Controls.MetroTextBox();
            this.tbE = new MetroFramework.Controls.MetroTextBox();
            this.tbPlaintext = new MetroFramework.Controls.MetroTextBox();
            this.tbCiphertext = new MetroFramework.Controls.MetroTextBox();
            this.lbP = new MetroFramework.Controls.MetroLabel();
            this.lbQ = new MetroFramework.Controls.MetroLabel();
            this.lbE = new MetroFramework.Controls.MetroLabel();
            this.btnGen = new MetroFramework.Controls.MetroButton();
            this.btnEncrypt = new MetroFramework.Controls.MetroButton();
            this.lbPlaintext = new MetroFramework.Controls.MetroLabel();
            this.lbCiphertext = new MetroFramework.Controls.MetroLabel();
            this.btnDecrypt = new MetroFramework.Controls.MetroButton();
            this.cbType = new MetroFramework.Controls.MetroComboBox();
            this.SuspendLayout();
            // 
            // tbP
            // 
            // 
            // 
            // 
            this.tbP.CustomButton.Image = null;
            this.tbP.CustomButton.Location = new System.Drawing.Point(443, 1);
            this.tbP.CustomButton.Name = "";
            this.tbP.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbP.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbP.CustomButton.TabIndex = 1;
            this.tbP.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbP.CustomButton.UseSelectable = true;
            this.tbP.CustomButton.Visible = false;
            this.tbP.Lines = new string[0];
            this.tbP.Location = new System.Drawing.Point(49, 63);
            this.tbP.MaxLength = 32767;
            this.tbP.Name = "tbP";
            this.tbP.PasswordChar = '\0';
            this.tbP.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbP.SelectedText = "";
            this.tbP.SelectionLength = 0;
            this.tbP.SelectionStart = 0;
            this.tbP.ShortcutsEnabled = true;
            this.tbP.Size = new System.Drawing.Size(465, 23);
            this.tbP.TabIndex = 0;
            this.tbP.UseSelectable = true;
            this.tbP.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbP.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // tbQ
            // 
            // 
            // 
            // 
            this.tbQ.CustomButton.Image = null;
            this.tbQ.CustomButton.Location = new System.Drawing.Point(443, 1);
            this.tbQ.CustomButton.Name = "";
            this.tbQ.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbQ.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbQ.CustomButton.TabIndex = 1;
            this.tbQ.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbQ.CustomButton.UseSelectable = true;
            this.tbQ.CustomButton.Visible = false;
            this.tbQ.Lines = new string[0];
            this.tbQ.Location = new System.Drawing.Point(49, 92);
            this.tbQ.MaxLength = 32767;
            this.tbQ.Name = "tbQ";
            this.tbQ.PasswordChar = '\0';
            this.tbQ.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbQ.SelectedText = "";
            this.tbQ.SelectionLength = 0;
            this.tbQ.SelectionStart = 0;
            this.tbQ.ShortcutsEnabled = true;
            this.tbQ.Size = new System.Drawing.Size(465, 23);
            this.tbQ.TabIndex = 1;
            this.tbQ.UseSelectable = true;
            this.tbQ.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbQ.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // tbE
            // 
            // 
            // 
            // 
            this.tbE.CustomButton.Image = null;
            this.tbE.CustomButton.Location = new System.Drawing.Point(444, 1);
            this.tbE.CustomButton.Name = "";
            this.tbE.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbE.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbE.CustomButton.TabIndex = 1;
            this.tbE.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbE.CustomButton.UseSelectable = true;
            this.tbE.CustomButton.Visible = false;
            this.tbE.Lines = new string[0];
            this.tbE.Location = new System.Drawing.Point(48, 121);
            this.tbE.MaxLength = 32767;
            this.tbE.Name = "tbE";
            this.tbE.PasswordChar = '\0';
            this.tbE.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbE.SelectedText = "";
            this.tbE.SelectionLength = 0;
            this.tbE.SelectionStart = 0;
            this.tbE.ShortcutsEnabled = true;
            this.tbE.Size = new System.Drawing.Size(466, 23);
            this.tbE.TabIndex = 2;
            this.tbE.UseSelectable = true;
            this.tbE.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbE.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // tbPlaintext
            // 
            // 
            // 
            // 
            this.tbPlaintext.CustomButton.Image = null;
            this.tbPlaintext.CustomButton.Location = new System.Drawing.Point(469, 1);
            this.tbPlaintext.CustomButton.Name = "";
            this.tbPlaintext.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbPlaintext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbPlaintext.CustomButton.TabIndex = 1;
            this.tbPlaintext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbPlaintext.CustomButton.UseSelectable = true;
            this.tbPlaintext.CustomButton.Visible = false;
            this.tbPlaintext.Lines = new string[0];
            this.tbPlaintext.Location = new System.Drawing.Point(23, 195);
            this.tbPlaintext.MaxLength = 32767;
            this.tbPlaintext.Name = "tbPlaintext";
            this.tbPlaintext.PasswordChar = '\0';
            this.tbPlaintext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbPlaintext.SelectedText = "";
            this.tbPlaintext.SelectionLength = 0;
            this.tbPlaintext.SelectionStart = 0;
            this.tbPlaintext.ShortcutsEnabled = true;
            this.tbPlaintext.Size = new System.Drawing.Size(491, 23);
            this.tbPlaintext.TabIndex = 3;
            this.tbPlaintext.UseSelectable = true;
            this.tbPlaintext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbPlaintext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // tbCiphertext
            // 
            // 
            // 
            // 
            this.tbCiphertext.CustomButton.Image = null;
            this.tbCiphertext.CustomButton.Location = new System.Drawing.Point(469, 1);
            this.tbCiphertext.CustomButton.Name = "";
            this.tbCiphertext.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbCiphertext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbCiphertext.CustomButton.TabIndex = 1;
            this.tbCiphertext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbCiphertext.CustomButton.UseSelectable = true;
            this.tbCiphertext.CustomButton.Visible = false;
            this.tbCiphertext.Lines = new string[0];
            this.tbCiphertext.Location = new System.Drawing.Point(23, 259);
            this.tbCiphertext.MaxLength = 32767;
            this.tbCiphertext.Name = "tbCiphertext";
            this.tbCiphertext.PasswordChar = '\0';
            this.tbCiphertext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbCiphertext.SelectedText = "";
            this.tbCiphertext.SelectionLength = 0;
            this.tbCiphertext.SelectionStart = 0;
            this.tbCiphertext.ShortcutsEnabled = true;
            this.tbCiphertext.Size = new System.Drawing.Size(491, 23);
            this.tbCiphertext.TabIndex = 4;
            this.tbCiphertext.UseSelectable = true;
            this.tbCiphertext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbCiphertext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lbP
            // 
            this.lbP.AutoSize = true;
            this.lbP.Location = new System.Drawing.Point(23, 60);
            this.lbP.Name = "lbP";
            this.lbP.Size = new System.Drawing.Size(20, 19);
            this.lbP.TabIndex = 5;
            this.lbP.Text = "p:";
            // 
            // lbQ
            // 
            this.lbQ.AutoSize = true;
            this.lbQ.Location = new System.Drawing.Point(23, 92);
            this.lbQ.Name = "lbQ";
            this.lbQ.Size = new System.Drawing.Size(20, 19);
            this.lbQ.TabIndex = 6;
            this.lbQ.Text = "q:";
            // 
            // lbE
            // 
            this.lbE.AutoSize = true;
            this.lbE.Location = new System.Drawing.Point(23, 125);
            this.lbE.Name = "lbE";
            this.lbE.Size = new System.Drawing.Size(19, 19);
            this.lbE.TabIndex = 7;
            this.lbE.Text = "e:";
            // 
            // btnGen
            // 
            this.btnGen.Location = new System.Drawing.Point(520, 63);
            this.btnGen.Name = "btnGen";
            this.btnGen.Size = new System.Drawing.Size(86, 81);
            this.btnGen.TabIndex = 8;
            this.btnGen.Text = "Generate";
            this.btnGen.UseSelectable = true;
            this.btnGen.Click += new System.EventHandler(this.btnGen_Click);
            // 
            // btnEncrypt
            // 
            this.btnEncrypt.Location = new System.Drawing.Point(521, 189);
            this.btnEncrypt.Name = "btnEncrypt";
            this.btnEncrypt.Size = new System.Drawing.Size(86, 29);
            this.btnEncrypt.TabIndex = 9;
            this.btnEncrypt.Text = "Encrypt";
            this.btnEncrypt.UseSelectable = true;
            this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // lbPlaintext
            // 
            this.lbPlaintext.AutoSize = true;
            this.lbPlaintext.Location = new System.Drawing.Point(48, 173);
            this.lbPlaintext.Name = "lbPlaintext";
            this.lbPlaintext.Size = new System.Drawing.Size(58, 19);
            this.lbPlaintext.TabIndex = 10;
            this.lbPlaintext.Text = "Plaintext";
            // 
            // lbCiphertext
            // 
            this.lbCiphertext.AutoSize = true;
            this.lbCiphertext.Location = new System.Drawing.Point(46, 237);
            this.lbCiphertext.Name = "lbCiphertext";
            this.lbCiphertext.Size = new System.Drawing.Size(70, 19);
            this.lbCiphertext.TabIndex = 11;
            this.lbCiphertext.Text = "Ciphertext";
            // 
            // btnDecrypt
            // 
            this.btnDecrypt.Location = new System.Drawing.Point(521, 253);
            this.btnDecrypt.Name = "btnDecrypt";
            this.btnDecrypt.Size = new System.Drawing.Size(86, 29);
            this.btnDecrypt.TabIndex = 12;
            this.btnDecrypt.Text = "Decrypt";
            this.btnDecrypt.UseSelectable = true;
            this.btnDecrypt.Click += new System.EventHandler(this.btnDecrypt_Click);
            // 
            // cbType
            // 
            this.cbType.FormattingEnabled = true;
            this.cbType.ItemHeight = 23;
            this.cbType.Location = new System.Drawing.Point(393, 160);
            this.cbType.Name = "cbType";
            this.cbType.Size = new System.Drawing.Size(121, 29);
            this.cbType.TabIndex = 13;
            this.cbType.UseSelectable = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 302);
            this.Controls.Add(this.cbType);
            this.Controls.Add(this.btnDecrypt);
            this.Controls.Add(this.lbCiphertext);
            this.Controls.Add(this.lbPlaintext);
            this.Controls.Add(this.btnEncrypt);
            this.Controls.Add(this.btnGen);
            this.Controls.Add(this.lbE);
            this.Controls.Add(this.lbQ);
            this.Controls.Add(this.lbP);
            this.Controls.Add(this.tbCiphertext);
            this.Controls.Add(this.tbPlaintext);
            this.Controls.Add(this.tbE);
            this.Controls.Add(this.tbQ);
            this.Controls.Add(this.tbP);
            this.Name = "Form1";
            this.Text = "Mini RSA";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox tbP;
        private MetroFramework.Controls.MetroTextBox tbQ;
        private MetroFramework.Controls.MetroTextBox tbE;
        private MetroFramework.Controls.MetroTextBox tbPlaintext;
        private MetroFramework.Controls.MetroTextBox tbCiphertext;
        private MetroFramework.Controls.MetroLabel lbP;
        private MetroFramework.Controls.MetroLabel lbQ;
        private MetroFramework.Controls.MetroLabel lbE;
        private MetroFramework.Controls.MetroButton btnGen;
        private MetroFramework.Controls.MetroButton btnEncrypt;
        private MetroFramework.Controls.MetroLabel lbPlaintext;
        private MetroFramework.Controls.MetroLabel lbCiphertext;
        private MetroFramework.Controls.MetroButton btnDecrypt;
        private MetroFramework.Controls.MetroComboBox cbType;
    }
}

